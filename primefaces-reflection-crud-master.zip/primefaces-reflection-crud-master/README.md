primefaces-reflection-crud
==========================

Primefaces Crud example using Java reflection.

Requires WildFly 8

Compile and deploy
	
mvn clean install wildfly:deploy


